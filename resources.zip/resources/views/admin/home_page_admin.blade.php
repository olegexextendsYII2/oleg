@extends('admin.layout_admin')

	@section('content')
	<div class="table-responsive">
   	
   <ul class="nav nav-pills">
    <li class="active"><a href="{{route('portfolio.index')}}">портфолио</a></li>
    <li><a href="{{route('category.index')}}">категории</a></li>
     	
    </ul>
   </div>
   
<div class="container">

<div class="row">
<div class="col-md-6">
<h2>Heading</h2>
<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
<p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
</div>
<div class="col-md-6">
<h2>Heading</h2>
<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
<p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
</div>

</div>

 

      
	@endsection

 